L=0.409;
u2= 2.71e-5;
v2=-8.62e-5;
u1=0;
v1=0;
t=105/180*pi;

ee=[(u2*cos(t)+v2*sin(t))-(u1*cos(t)+v1*sin(t))]/L