syms x 
solve(300^2+(500-x)^2-(300+x)^2==0);
double(ans)