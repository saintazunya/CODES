syms x
it=int( 20*(1-exp(-0.5*x)),0,1)
power=int(20*(1-exp(-0.5*x))*10*cos(2*x),0,1)